module.exports = {
        reactStrictMode: true,
    };
    